<?php $__env->startSection('main'); ?>
<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="featured-image" style="background-image: url(<?php echo e(asset(('Images/cover/'.$text->image))); ?>);"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<section class="container padding-top-3x padding-bottom-3x">
    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h1><?php echo e($text->title); ?></h1>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row padding-top">
        <div class="col-md-9 col-sm-6 padding-bottom">
            <h3>Oculus</h3>
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p class=" space-top"><?php echo e($text->article); ?></p>
        </div><!-- .col-md-5.col-sm-6 -->
       
    </div><!-- .row -->
 
    <hr class="padding-bottom">
    <h3>Our Team</h3>
    <div class="row padding-top">
        <!-- Teammate -->
        <div class="col-xs-6 col-md-3">
            <div class="teammate">
                <div class="teammate-thumb">
                    <div class="social-bar text-center space-bottom">
                        <a href="#" class="sb-skype" data-toggle="tooltip" data-placement="top" title="Skype">
                            <i class="socicon-skype"></i>
                        </a>
                        <a href="#" class="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i class="socicon-facebook"></i>
                        </a>
                        <a href="#" class="sb-google-plus" data-toggle="tooltip" data-placement="top" title=""
                            data-original-title="Google+">
                            <i class="socicon-googleplus"></i>
                        </a>
                    </div><!-- .social-bar -->
                    <img src="<?php echo e(asset(('library/MD-shop/img/team/01.jpg'))); ?>" alt="Teammate">
                </div>
                <h4 class="teammate-name">Jonathan Doe</h4>
                <span class="teammate-position">Co-Founder, CEO</span>
            </div><!-- .teammate -->
        </div><!-- .col-xs-6.col-md-3 -->
        <!-- Teammate -->
        <div class="col-xs-6 col-md-3">
            <div class="teammate">
                <div class="teammate-thumb">
                    <div class="social-bar text-center space-bottom">
                        <a href="#" class="sb-twitter" data-toggle="tooltip" data-placement="top" title="Twitter">
                            <i class="socicon-twitter"></i>
                        </a>
                        <a href="#" class="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i class="socicon-facebook"></i>
                        </a>
                        <a href="#" class="sb-instagram" data-toggle="tooltip" data-placement="top" title=""
                            data-original-title="Instagram">
                            <i class="socicon-instagram"></i>
                        </a>
                    </div><!-- .social-bar -->
                    <img src="<?php echo e(asset(('library/MD-shop/img/team/02.jpg'))); ?>" alt=" Teammate">
                </div>
                <h4 class="teammate-name">Branda Murray</h4>
                <span class="teammate-position">Marketing Director</span>
                
            </div><!-- .teammate -->
        </div><!-- .col-xs-6.col-md-3 -->
        <!-- Teammate -->
        <div class="col-xs-6 col-md-3">
            <div class="teammate">
                <div class="teammate-thumb">
                    <div class="social-bar text-center space-bottom">
                        <a href="#" class="sb-twitter" data-toggle="tooltip" data-placement="top" title="Twitter">
                            <i class="socicon-twitter"></i>
                        </a>
                        <a href="#" class="sb-linkedin" data-toggle="tooltip" data-placement="top" title="LinkedIn">
                            <i class="socicon-linkedin"></i>
                        </a>
                        <a href="#" class="sb-dribbble" data-toggle="tooltip" data-placement="top" title=""
                            data-original-title="Dribbble">
                            <i class="socicon-dribbble"></i>
                        </a>
                    </div><!-- .social-bar -->
                    <img src="<?php echo e(asset(('library/MD-shop/img/team/03.jpg'))); ?>" alt="Teammate">
                </div>
                <h4 class="teammate-name">Taylor White</h4>
                <span class="teammate-position">Brand Director</span>
            </div><!-- .teammate -->
        </div><!-- .col-xs-6.col-md-3 -->
        <!-- Teammate -->
        <div class="col-xs-6 col-md-3">
            <div class="teammate">
                <div class="teammate-thumb">
                    <div class="social-bar text-center space-bottom">
                        <a href="#" class="sb-skype" data-toggle="tooltip" data-placement="top" title="Skype">
                            <i class="socicon-skype"></i>
                        </a>
                        <a href="#" class="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i class="socicon-facebook"></i>
                        </a>
                        <a href="#" class="sb-google-plus" data-toggle="tooltip" data-placement="top" title=""
                            data-original-title="Google+">
                            <i class="socicon-googleplus"></i>
                        </a>
                    </div><!-- .social-bar -->
                    <img src="<?php echo e(asset(('library/MD-shop/img/team/04.jpg'))); ?>" alt="Teammate">
                </div>
                <h4 class="teammate-name">Suasanna Davis</h4>
                <span class="teammate-position">Sales Director</span>
            </div><!-- .teammate -->
        </div><!-- .col-xs-6.col-md-3 -->
    </div><!-- .row -->
</section><!-- .container -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>