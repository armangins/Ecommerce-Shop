<?php $__env->startSection('main_cms'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <form autocomplete="off" action="<?php echo e(url('cms/menu/'.$item_id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('DELETE')); ?>

        <h3>Are you sure you want to delete this menu ?</h3>
        <div class="row p-2">
                <input class="btn btn-success " type="submit" value="Delete ">
                <a class="btn btn-danger ml-2" href="<?php echo e(url('cms/menu')); ?>">Cancel</a>
        </div>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>