 <!--Favicon-->
 <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
 <link rel="icon" href="favicon.ico" type="image/x-icon">

 <!-- Google Material Icons -->
 <link href="<?php echo e(asset('library/MD-shop/css/vendor/material-icons.min.css')); ?>" rel="stylesheet" media="screen">

 <!-- Brand Icons -->
 <link href="<?php echo e(asset('library/MD-shop/css/vendor/socicon.min.css')); ?>" rel="stylesheet" media="screen">

 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">

 <!-- Bootstrap -->
 <link href="<?php echo e(asset('library/MD-shop/css/vendor/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">

 <!-- Theme Styles -->
 <link href="<?php echo e(asset('library/MD-shop/css/theme.min.css')); ?>" rel="stylesheet" media="screen">

 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

 <link rel="stylesheet" href="<?php echo e(asset('library/colorlib-error-404-9/css/style.css')); ?>">

 <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" media="screen">


 <!-- Modernizr -->
 <script src="<?php echo e(asset('library/MD-shop/js/vendor/modernizr.custom.js')); ?>"></script>