<?php $__env->startSection('shoping-cart'); ?>
 <!-- Container -->
 <section class="container padding-top-3x padding-bottom">

    <h1 class="space-top-half">Shopping Cart</h1>
    <div class="row padding-top">

      <!-- Cart -->
      <div class="col-sm-8 padding-bottom-2x">
        <p class="text-sm">
          <span class="text-gray">Currently</span> 3 items
          <span class="text-gray"> in cart</span>
        </p>
        <div class="shopping-cart">
          <!-- Item -->
          <div class="item">
            <a href="shop-single.html" class="item-thumb">
              <img src="<?php echo e(asset('library/MD-shop/img/cart/item01.jpg')); ?>" alt="Item">
            </a>
            <div class="item-details">
              <h3 class="item-title"><a href="shop-single.html">Concrete Lamp</a></h3>
              <h4 class="item-price">$85.90</h4>
              <div class="count-input">
                <a class="incr-btn"  href="#">–</a>
                <input class="quantity" type="text" value="1">
                <a class="incr-btn"  href="#">+</a>
              </div>
            </div>
            <a href="#" class="item-remove" data-toggle="tooltip" data-placement="top" title="Remove">
              <i class="material-icons remove_shopping_cart"></i>
            </a>
          </div><!-- .item -->
         
        </div><!-- .shopping-cart -->
        <!-- Coupon -->
      
      </div><!-- .col-sm-8 -->

      <!-- Sidebar -->
      <div class="col-md-3 col-md-offset-1 col-sm-4 padding-bottom-2x">
        <aside>
          <h3 class="toolbar-title">Cart subtotal:</h3>
          <h4 class="amount">$460.90</h4>
          <p class="text-sm text-gray">* Note: This amount does not include costs for international shipping. You will be able to calculate shipping costs on checkout.</p>
          <a href="#" class="btn btn-default btn-block waves-effect waves-light">Update Cart</a>
          <a href="checkout.html" class="btn btn-primary btn-block waves-effect waves-light space-top-none">Checkout</a>
        </aside>
      </div><!-- .col-md-3.col-sm-4 -->
    </div><!-- .row -->
  </section><!-- .container -->

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>