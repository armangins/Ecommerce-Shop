<?php if($paginator->hasPages()): ?>
<div class="pagination padding-bottom">
        <div class="page-numbers">
        
        <?php if($paginator->onFirstPage()): ?>
            <a class="disabled" aria-disabled="true" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>">
                <span aria-hidden="true">&lsaquo;</span>
            </a>
        <?php else: ?>
   
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->getFromJson('pagination.previous'); ?>"> &lsaquo; Prev..</a>
       
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <a class="disabled" aria-disabled="true"><span><?php echo e($element); ?></span></a>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <a class="active" aria-current="page"><span><?php echo e($page); ?></span></a>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
        <div class="pager">
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">Next &rsaquo;</a>
            </div>
        <?php else: ?>
            <a class="disabled" aria-disabled="true" aria-label="<?php echo app('translator')->getFromJson('pagination.next'); ?>">
                <span aria-hidden="true">&rsaquo;</span>
            </a>
        <?php endif; ?>
    </div>
    </div><!-- .col-md-9 col-sm-8 -->
<?php endif; ?>
 
     
     