<header class="navbar navbar-sticky">
    <!-- Site Logo -->
    <a href="<?php echo e(url('/')); ?>" class="site-logo visible-desktop">
        <span>O</span> C
        <span class="text-gray">U</span>
        LUS <span></span>
    </a>
    <!-- site-logo.visible-desktop -->
    <a href="<?php echo e(url('/')); ?>" class="site-logo visible-mobile">
        <span>[</span> M <span>]</span>
    </a><!-- site-logo.visible-mobile -->
    <!-- Main Navigation -->
    <!-- Control the position of navigation via modifier classes: "text-left, text-center, text-right" -->
    <nav class="main-navigation text-center">
        <ul class="menu">
            <li class="menu-item-has-children current-menu-item">
            <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
            <li><a href="<?php echo e(url('shop/all')); ?>">Shop</a></li>
            <li><a href="<?php echo e(url('shop/cart')); ?>">Shopping Cart</a></li>
            </li>
            <li class="menu-item-has-children">
                <a href="#"> User</a>
                <ul class="sub-menu">
                    
                    <?php if((Session::has('admin'))): ?>
                    <li><a href="<?php echo e(url('cms/dashboard')); ?>">Admin-Panel</a></li>
                    <?php endif; ?>
                    
                    
                    <?php if(Session::has('id')): ?>
                    <li><a href="<?php echo e(url('user/logout')); ?>">Log-out</a></li>
                    <?php else: ?>
                    <li><a href="<?php echo e(url('user/login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(url('user/register')); ?>">Register</a></li>
                    <?php endif; ?>
                    
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="#">Pages</a>
                <ul class="sub-menu">
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(url($link['url'])); ?>"><?php echo e($link['link']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        </ul>
        <!-- .menu -->
    </nav>
    <!-- .main-navigation -->
    <!-- Toolbar -->
    <div class="toolbar">
        <div class="inner">
            <p style="padding:0px; margin-top:32px">

                
                <?php if(Session::has('id')): ?>
                <?php echo e(Session::get('name')); ?>

                <?php endif; ?></p>
            

            <a href="#" class="mobile-menu-toggle"> <i class="material-icons menu"></i></a>
            <a href="#"> <i class="material-icons person"></i>
            </a>
            <div class="cart-btn">
                <a href="<?php echo e(url('shop/cart')); ?>">
                    <i>
                        <span class="material-icons shopping_basket"></span>
                        
                        <?php if(!Cart::isEmpty()): ?>
                        <span class="count">
                            <?php echo e(Cart::getTotalQuantity()); ?>

                        </span>
                        <?php endif; ?>
                        
                    </i>
                </a>
                <!-- Cart Dropdown -->
                
                <?php if(!Cart::isEmpty()): ?>
                <?php $__currentLoopData = Cart::getContent()->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="cart-dropdown">
                    <div class="cart-item">
                        <a href="<?php echo e(url('shop/cart')); ?>" class="item-thumb">
                            <img src="<?php echo e(asset('Images/products/'.$product['attributes']['image'])); ?>" alt="Item">
                        </a>
                        <div class="item-details">
                            <h3 class="item-title"><?php echo e($product['name']); ?></h3>
                            <h4 class="item-price"> x <?php echo e($product['quantity']); ?> $<?php echo e($product['price']); ?></h4>
                        </div>
                        <a type="button" href="<?php echo e(url('shop/remove-item-drop?pid='.$product['id'])); ?>" class="close-btn">
                            <i class="material-icons close"></i>
                        </a>
                    </div>
                    <!-- .cart-item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="cart-subtotal">
                        <div class="column">
                            <span> Total :<?php echo e(Cart::getTotal()); ?>$</span>
                        </div>
                        <div class="column">
                            <span class="amount"> Total in cart :<?php echo e(Cart::getContent()->count()); ?></span>
                        </div>
                    </div>
                </div>
                <!-- .cart-dropdown -->
                <?php endif; ?>
                
            </div>
            <!-- .cart-btn -->
        </div>
        <!-- .inner -->
    </div>
    <!-- .toolbar -->
</header>
<!-- .navbar.navbar-sticky -->
