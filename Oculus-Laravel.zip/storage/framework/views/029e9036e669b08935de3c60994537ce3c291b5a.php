<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

  
    <!-- Google Material Icons -->
    <link href="<?php echo e(asset('library/MD-shop/css/vendor/material-icons.min.css')); ?>" rel="stylesheet" media="screen">

    <!-- Brand Icons -->
    <link href="<?php echo e(asset('library/MD-shop/css/vendor/socicon.min.css')); ?>" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="<?php echo e(asset('library/MD-shop/css/vendor/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
    
    <!-- Theme Styles -->
    <link href="<?php echo e(asset('library/MD-shop/css/theme.min.css')); ?>" rel="stylesheet" media="screen">

    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">

    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" media="screen">

    <link href="<?php echo e(asset('library/colorlib-error-404-9/css/style.css')); ?>" rel="stylesheet" media="screen">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">

    <link href="<?php echo e(asset('dist/css/lightbox.css')); ?>" rel="stylesheet">
