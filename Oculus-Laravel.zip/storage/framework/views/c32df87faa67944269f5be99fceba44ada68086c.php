<?php $__env->startSection('main'); ?>

<!-- Featured Image -->
<div class="featured-image" style="background-image: url(<?php echo e(asset('library/MD-shop/img/featured-image/blog.jpg')); ?>);"></div>

<!-- Single Post Content -->
<section class="single-post-wrap">
    <!-- Close Btn -->
    <span class="close-btn"><i class="material-icons close"></i></span>
    <!-- Preloader -->
    <div class="preloader">
        <img src="<?php echo e(asset('library/MD-shop/img/preloader.gif')); ?>" alt="Preloader">
    </div>
    <div class="inner">
        <div class="post-content">
            <!-- Content loaded via Ajax goes here -->
        </div><!-- .post-content -->
        <div class="post-share">
            <span>Share this post:&nbsp;&nbsp;&nbsp;</span>
            <div class="social-bar">
                <a href="#" class="sb-facebook" data-toggle="tooltip" data-placement="top" title="" data-original-title="Facebook">
                    <i class="socicon-facebook"></i>
                </a>
                <a href="#" class="sb-twitter" data-toggle="tooltip" data-placement="top" title="" data-original-title="Twitter">
                    <i class="socicon-twitter"></i>
                </a>
                <a href="#" class="sb-instagram" data-toggle="tooltip" data-placement="top" title=""
                    data-original-title="Instagram">
                    <i class="socicon-instagram"></i>
                </a>
            </div>
        </div><!-- .post-share -->
    </div><!-- .inner -->
</section><!-- .single-post-wrap -->

<!-- Single Post Backdrop -->
<div class="single-post-backdrop"></div>

<!-- Content -->
<section class="container padding-top-3x padding-bottom">
    <h1>Blog</h1>

    <!-- Post -->
    <div class="row padding-top paddin-bottom">
        <div class="col-md-3 col-sm-4">
            <div class="blog-post-meta">
                <div class="column">
                    <span>by </span>
                    <a href="#">Rokaux</a>
                    <span class="divider"></span>
                    <a href="#">Jul 24</a>
                </div>
                <div class="column">
                    <a href="#">
                        <i class="material-icons favorite_border"></i>
                        13
                    </a>
                </div>
            </div>
            <h2 class="blog-post-title"><a href="blog/single-post01.html" class="ajax-post-link">Post Article Title</a></h2>
        </div>
        <div class="col-md-offset-1 col-sm-8">
            <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum
                deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non
                provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga.
                Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est
                eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas
                assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum
                necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.</p>
            <div class="blog-post-meta space-top">
                <div class="column">
                    <span>in </span>
                    <a href="#">Category name</a>
                    <span class="divider"></span>
                    <a href="#">#tagname</a>
                </div>
                <div class="column">
                    <a href="blog/single-post01.html" class="read-more ajax-post-link">Read More</a>
                </div>
            </div>
        </div>
    </div><!-- .row -->
    <hr>
        <!-- Pagination -->
        <div class="pagination">
            <div class="page-numbers">
                <a href="#">1</a>
                <a href="#">2</a>
                <span class="active">3</span>
                <a href="#">4</a>
                <span>...</span>
                <a href="#">10</a>
            </div>
            <div class="pager">
                <a href="#">Prev</a>
                <span>|</span>
                <a href="#">Next</a>
            </div>
        </div>
</section><!-- .container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>