<?php $__env->startSection('main_cms'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center  border-bottom">
        <h1 class="h2">Orders List</h1>
        <hr>
    </div>
    <div class="row">
        <div class="col-9 mx-auto mt-5">
            <table class="table table-striped table">
                <thead class="" style="background-color:#38ada9">
                    <tr>
                        <th class="text-center" scope="col">User</th>
                        <th class="text-center" scope="col">Total Price</th>
                        <th class="" scope="col">Order details</th>
                        <th class="" scope="col">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($order->name); ?></td>
                        <td class="text-center">$<?php echo e($order->total); ?>.00</td>
                        <td class="">
                            <ol>
                                <?php $__currentLoopData = unserialize($order->data); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li> Product:<?php echo e($item['name']); ?>,price : $<?php echo e($item['price']); ?>.00,Quantity: <?php echo e($item['quantity']); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </td>
                        <td class="">
                            <?php echo e(date('d/m/Y', strtotime($order->created_at))); ?>

                        </td>
                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
   

</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>