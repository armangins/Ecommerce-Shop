<?php $__env->startSection('main_cms'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <form enctype="multipart/form-data" autocomplete="off" action="<?php echo e(url('cms/products')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="col-6">
            <?php if($errors): ?>
            <div class="form-group">
                <label for="formGroupExampleInput2">Product title:</label>
                <input name="title" type="text" class="form-control original-text" id="formGroupExampleInput2"
                    placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">URL:</label>
                <input name="url" type="text" class="form-control target-text" id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Price:</label>
                <input name="price" type="text" class="form-control " id="formGroupExampleInput2" placeholder="Another input">
            </div>
            <div class="  form-group">
                <label for="categorie_id">Category links:</label>
                <select class="mx-auto form-control" name="categorie_id" id="categorie_id">
                    <option name="categorie_id" class="text-center" value="Choose menu link please">Select category...</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option name="categorie_id" <?php if(old('categorie_id')==$category['id']): ?> selected="selected" <?php endif; ?> value="<?php echo e($category['id']); ?>"><?php echo e($category['ctitle']); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Article:</label>
                <textarea value='' class="form-control" name="article" id="article"></textarea>
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                </div>
                <div class="custom-file">
                    <input name="image" type="file" class="custom-file-input" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                    <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                </div>
            </div>
            <div class="form-group">
                <input name="submit" type="submit" class=" btn btn-primary form-control" id="formGroupExampleInput2"
                    placeholder="Another input">
            </div>
        </div>
        <?php endif; ?>
    </form>
    <?php if($errors->any()): ?>
    <div style="color:red" class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>