<?php $__env->startSection('main'); ?>
<!-- Featured Image -->
<div class="featured-image" style="background-image: url( <?php echo e(asset('Images/cover/login.jpeg')); ?>"></div>
<!-- Content -->
<section class="container padding-top-3x padding-bottom-2x">
    <h1>User Account</h1>
    <div class="row padding-top">
        <div class="col-md-6 padding-bottom">
            <h3>Login</h3>
            <form method="POST" class="login-form" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <input value="<?php echo e(old('email')); ?>" name="email" type="text" class="form-control" placeholder="E-mail"
                    required>
                <input name="password" type="password" class="form-control" placeholder="Password" required>
                <div class="form-footer">
                    <div class="rememberme">
                        
                        <?php if(!empty($loginError)): ?>
                        <span class="text-danger">*<?php echo e($loginError); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-submit">
                        <button name="submit" type="submit" class="btn btn-primary btn-block waves-effect waves-light">Login</button>
                    </div>
                </div>
            </form><!-- .login-form -->
        </div><!-- .col-md-4 -->
        <div class="col-md-3 padding-top-2x">
            <?php if($errors->any()): ?>
            <div style="color:red" class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div><!-- .col-md-3 -->
    </div><!-- .row -->
</section><!-- .container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>