<?php $__env->startSection('main'); ?>
<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="featured-image" style="background-image: url(<?php echo e(asset(('Images/cover/'.$text->image))); ?>);"></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<section class="container padding-top-3x padding-bottom-3x">
    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h1><?php echo e($text->title); ?></h1>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="row padding-top">
        <div class="col-md-9 col-sm-6 padding-bottom">
            <h3>Oculus</h3>

            <p class=" space-top"><?php echo e($text->article); ?></p>
        </div><!-- .col-md-5.col-sm-6 -->
    </div><!-- .row -->
    <hr class="padding-bottom">
   
    <div class="row padding-top">
    
       
    </div><!-- .row -->
</section><!-- .container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>