<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    
    <title><?php if(!empty($pageTitle)): ?>
        <?php echo e($pageTitle); ?>

        <?php endif; ?></title>
    
    <!--SEO Meta Tags-->
    <meta name="description" content="A Demo shop just for portfolio" />
    <meta name="keywords" content="shop, e-commerce, modern, minimalist style, responsive, online store, business, mobile, blog, bootstrap, html5, css3, jquery, js, gallery, slider, touch, creative, clean" />
    <meta name="author" content="Arman" />
    <!--Mobile Specific Meta Tag-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <!--Favicon-->
    <?php echo $__env->make('include.header_css', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Modernizr -->
    <script src="<?php echo e(asset('library/MD-shop/js/vendor/modernizr.custom.js')); ?>"></script>
</head>

<script>
    var BASE_URL = "<?php echo e(url('')); ?>/"
</script>

<!-- Body -->
<body>
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <?php echo $__env->make('include.header_nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('main'); ?>
        <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div><!-- .page-wrapper -->
    <?php echo $__env->make('include.js', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body><!-- <body> -->
</html>
