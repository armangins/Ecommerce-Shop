<?php $__env->startSection('main'); ?>;
<section class="container-fluid padding-top-3x padding-bottom-3x">
    <!-- Sidebar Toggle / visible only on mobile -->
    <div class="sidebar-toggle">
        <i class="material-icons filter_list"></i>
    </div>
    <h1 class="space-top-half">Full-Shop</h1>
    <div class="row padding-top">

        <!-- Sidebar (Filters) -->
        <div class="col-lg-2 col-md-3 col-sm-4">
            <aside class="sidebar">
                <span class="sidebar-close"><i class="material-icons close"></i></span>
                <div class="widgets">
                    <!-- Categories Widget -->
                    <div class="widget widget-categories">
                        <h3 class="widget-title">Categories</h3>
                        <ul>
                            <li  class="active"><a href="<?php echo e(url('shop/all')); ?>">All <?php if($total): ?><?php echo e($total); ?><?php endif; ?></a></li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="active my-li"><a href="<?php echo e(url('shop/'.$category['curl'])); ?>"><?php echo e($category['ctitle']); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div><!-- .widget.widget-categories -->
                    <!-- Sorting Widget -->
                    <div class="widget widget-price">
                        <h3 class="widget-title">Price Filter</h3>
                        <ul>
                         
                            <li class="active"><a href="<?php echo e(Request::url().'?order=ASC'); ?>">Low to High</a></li>
                            <li><a href="<?php echo e(Request::url().'?order=DESC'); ?>">High to low</a></li>
                        </ul>
                    </div>
                    <!-- .widget.widget-price -->
                </div>
                <!-- .widgets -->
            </aside>
            <!-- .sidebar -->
        </div>
        <!-- .col-md-3.col-sm-4 -->

        <!-- Products Grid -->
        <div class="col-lg-10 col-md-9 col-sm-8">
            <!-- Shop Bar -->
            <div class="shop-bar">

                
                <!-- .column -->
            </div>
            <!-- .shop-bar -->
            <div class="row">
                
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- Item -->
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="shop-item">
                        <div class="shop-thumbnail">
                            <?php if($item->onsale): ?>
                            <span class="shop-label text-danger">Sale</span>
                            <?php endif; ?>
                            
                            
                            <a href="<?php echo e(asset('Images/products/' .$item->pimage)); ?>" data-lightbox="image-1" data-title="<?php echo e($item->ptitle); ?>">
                                <img src="<?php echo e(asset('Images/products/' .$item->pimage)); ?>" alt="Shop item"></a>
                          
                            <div class="shop-item-tools">
                                <a href="<?php echo e(url('shop/'.$item->curl.'/'.$item->purl)); ?>" class="add-to-whishlist"
                                    data-toggle="tooltip" data-placement="top" title="More info">
                                    <i class="fas fa-info-circle"></i>
                                </a>
                                
                                <?php if(!Cart::get($item->id)): ?>
                                <a data-id="<?php echo e($item->id); ?>" href="#" class="add-to-cart add-to-cart-btn">
                                    <em>Add to cart</em>
                                    <svg x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32">
                                        <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79" fill="none"
                                            stroke="#FFFFFF" stroke-width="2" stroke-linecap="square" stroke-miterlimit="10"
                                            d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11" />
                                    </svg>
                                </a>
                                <?php else: ?>
                                <a class="add-to-cart text-white">
                                    <em>I'm In cart</em>
                                </a>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        <div class="shop-item-details">
                            <h3 class="shop-item-title"><a href="#"><?php echo $item->ptitle; ?></a></h3>

                            <span class="shop-item-price">
                                <span class="old-price">$<?php echo $item->price /0.5; ?>.00</span>
                                $<?php echo e($item->price); ?>.00
                            </span>
                        </div>
                    </div>
                    <!-- .shop-item -->
                </div>
                <!-- .col-md-4.col-sm-6 -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <!-- .row -->
            <hr>
            <div class="pagination padding-bottom">
                <div class="page-numbers">
                     <?php echo e($products->appends(request()->query())->links("pagination::default")); ?> 
               
                </div>
               
              </div>
            </div><!-- .col-md-9 col-sm-8 -->
 
   
        </div>
    </div><!-- .col-md-9 col-sm-8 -->
    </div><!-- .row -->
</section><!-- .container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>