<?php $__env->startSection('main'); ?>
<!-- Featured Image -->
<div class="featured-image" style="background-image: url( <?php echo e(asset('Images/cover/register.jpeg')); ?>"></div>
<!-- Content -->
<section class="container padding-top-3x padding-bottom-2x">
    <h1>User Account</h1>
    <div class="row padding-top">
        <div class="col-md-6 padding-bottom">
            <h3>Login</h3>
            <form method="POST" class="login-form" novalidate="novalidate">
                <?php echo csrf_field(); ?>
                <input value="<?php echo e(old('email')); ?>" name="email" type="text" class="form-control" placeholder="E-mail"
                    required>
                <span class="text-danger"> <?php echo e($errors->first('email')); ?></span>
                <input value="<?php echo e(old('name')); ?>" name="name" type="text" class="form-control" placeholder="name" required>
                <span class="text-danger"> <?php echo e($errors->first('name')); ?></span>
                <input name="password" type="password" class="form-control" placeholder="Password" required>
                <span class="text-danger"> <?php echo e($errors->first('password')); ?></span>
                <div class="form-footer">
                    <div class="form-submit">
                        <button name="submit" type="submit" class="btn btn-primary btn-block waves-effect waves-light">Register</button>
                    </div>
                </div>
            </form>
            <!-- .login-form -->
        </div>
    </div>
    <!-- .row -->
</section><!-- .container -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>