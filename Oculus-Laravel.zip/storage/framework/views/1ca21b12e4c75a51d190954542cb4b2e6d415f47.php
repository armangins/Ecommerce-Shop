<?php $__env->startSection('main'); ?>
<div class="product-gallery">
    <!-- Preview -->
    <ul class="product-gallery-preview">
        <li id="preview02" class="current"><img src="<?php echo e(asset('Images/products/' .$item['pimage'])); ?>" alt="Product"></li>
    </ul><!-- .product-gallery-preview -->
</div><!-- .product-gallery -->
<!-- Product Info -->
<section class="fw-section bg-gray padding-bottom-3x">
    <div class="container">
        <div class="product-info padding-top-2x text-center">
            <h1 class="h2 space-bottom-half"><?php echo e($item['ptitle']); ?></h1>
            <h2>$<?php echo e($item['price']); ?>.00</h2>
            <p class="text-sm text-gray"><?php echo $item['particle']; ?></p>
            <div class="product-meta">
                <div class="product-category">
                    <strong><?php echo e($categories['0']['ctitle']); ?></strong>
                    <a href="#"></a>
                </div>
                <span class="product-rating text-warning">
                    <i class="material-icons star"></i>
                    <i class="material-icons star"></i>
                    <i class="material-icons star"></i>
                    <i class="material-icons star"></i>
                    <i class="material-icons star_border"></i>
                </span>
            </div><!-- .product-meta -->
            <div class="product-tools shop-item">
                <h4>Go Back to :</h4>
                <a href="<?php echo e(url('shop/all')); ?>">All </a></li>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><a href="<?php echo e(url('shop/'.$category['curl'])); ?>"><?php echo e($category['ctitle']); ?></a></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div><!-- .form-element -->
            <?php if(!Cart::get($item['id'])): ?>
            <button data-id="<?php echo e($item['id']); ?>" id="cart" class="add-to-cart add-to-cart-btn" type="button"> <em>Add
                    to cart</em> </button>
            <?php else: ?>
            <button data-id="<?php echo e($item['id']); ?>" id="cart" class="add-to-cart" type="button" disabled="disabled"> <em>I'm In
                    cart</em> </button>
            <?php endif; ?>
            <svg x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32">
                <path stroke-dasharray="19.79 19.79" stroke-dashoffset="19.79" fill="none" stroke="#FFFFFF"
                    stroke-width="2" stroke-linecap="square" stroke-miterlimit="10" d="M9,17l3.9,3.9c0.1,0.1,0.2,0.1,0.3,0L23,11"></path>
            </svg>
            </a><!-- .add-to-cart -->
        </div><!-- .product-tools -->

    </div><!-- .product-info -->
    </div><!-- .container -->
</section><!-- .fw-section.bg-gray -->
<!-- Product Tabs -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>