<?php $__env->startSection('main_cms'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
        <form autocomplete="off" action="<?php echo e(url('cms/content/'.$item['id'])); ?>" action="" method="POST">
            <?php echo csrf_field(); ?><?php echo e(method_field('PUT')); ?>

            <input type="hidden" name="item_id" value="<?php echo e($item['id']); ?>">
   
        <div class="row">
                <div class="col-8">
                        <?php if($errors): ?>
                        <div class="form-group">
                            <label for="formGroupExampleInput">Title:</label>
                            <input name="title" value="<?php echo e($item['title']); ?>" type="text" class="form-control original-text" id="formGroupExampleInput"
                                >
                    
                        </div>
                        <div class="form-group">
                            <label for="formGroupExampleInput2">Article:</label>
                        <textarea value='' class="form-control" name="article" id="article" ><?php echo e($item['article']); ?></textarea>
                      
                        </div>
                        <div class="  form-group">
                            <label for="menu-id">Menu links:</label>
                            <select class="mx-auto form-control" name="menu_id" id="menu-id">
          
                                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if($item['menu_id']==$nav['id']): ?> selected="selected"  <?php endif; ?> value="<?php echo e($nav['id']); ?>"><?php echo e($nav['link']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            
                        </div>
                       
                        <div class="form-group">
                            <input value="Save" name="submit" type="submit" class=" btn btn-primary form-control" id="formGroupExampleInput2"
                                placeholder="Another input">
                        </div>
                    </div>
                    <div class="col-4 mt-5">
                            <?php if($errors->any()): ?>
                            <div style="color:red" class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                         <?php endif; ?>
                    </div>
                    <?php endif; ?>
        </div>
 
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>