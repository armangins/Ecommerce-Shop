<?php $__env->startSection('main_cms'); ?>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">
    <h1>Add menu here</h1>
    <form autocomplete="off" action="<?php echo e(url('cms/menu')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="col-6 mt-5">
            <?php if($errors): ?>
            <div class="form-group">
                <label for="formGroupExampleInput">Link name:</label>
                <input name="link" value="<?php echo e(old('link')); ?>" type="text" class="form-control original-text" id="formGroupExampleInput"
                    placeholder="Enter link name">
                <span class="text-danger"> <?php echo e($errors->first('link')); ?></span>
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Link URL:</label>
                <input name="url" type="text" class="form-control target-text" id="formGroupExampleInput2" placeholder="Another input">
                <span class="text-danger"> <?php echo e($errors->first('url')); ?></span>
            </div>
            <div class="form-group">
                <label for="formGroupExampleInput2">Page title:</label>
                <input name="title" type="text" class="form-control" id="formGroupExampleInput2" placeholder="Another input">
                <span class="text-danger"> <?php echo e($errors->first('title')); ?></span>
            </div>
            <div class="form-group">
                <input name="submit" type="submit" class=" btn btn-primary form-control" id="formGroupExampleInput2"
                    placeholder="Another input">
            </div>
        </div>
        <?php endif; ?>
    </form>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('cms.cms_master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>