<!-- JavaScript (jQuery) libraries, plugins and custom scripts -->
<script src="<?php echo e(asset('library/MD-shop/js/vendor/jquery-2.1.4.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/smoothscroll.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/velocity.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/waves.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/icheck.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/jquery.downCount.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('library/MD-shop/js/scripts.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="<?php echo e(asset('library/MD-shop/js/vendor/modernizr.custom.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
  
  <?php if(Session::has('message')): ?>;


  <script>
      <?php if(Session::has('toastnew')): ?>
      toastr.options.positionClass = "<?php echo e(Session::get('toastnew')); ?>";
      <?php else: ?>
      toastr.options.positionClass = "<?php echo e($toastr); ?>";
      <?php endif; ?>
      toastr.success("<?php echo e(Session::get('message')); ?>");

  </script>


  <?php endif; ?>